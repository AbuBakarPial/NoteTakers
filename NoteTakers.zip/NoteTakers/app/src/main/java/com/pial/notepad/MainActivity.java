package com.pial.notepad;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;


public class MainActivity extends AppCompatActivity {

    String[] filename, filepath, fileId, FilePN;
    DatabaseHelper helper = new DatabaseHelper(this);
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if(Build.VERSION.SDK_INT >=23 && (
                ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED ))
        {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent createText = new Intent(MainActivity.this, CreateText.class);
                startActivity(createText);
            }
        });
        getList();
    }
    public void getList() {
        TextView text = (TextView) findViewById(R.id.text);
        Cursor data = helper.getListContents();
        int count = 0;
        filename = new String[data.getCount()];
        filepath = new String[data.getCount()];
        fileId = new String[data.getCount()];
        while (data.moveToNext()) {
            fileId[count] = data.getString(0);
            filename[count] = data.getString(1);
            filepath[count] = data.getString(2);
            count++;
        }
        lv = (ListView) findViewById(R.id.listView);
        lv.setAdapter(null);
        if (data.getCount() == 0) {
            text.setText("There are no notes in this list! Please create one +!");
        } else {
            lv.setAdapter(new TextList(this, filename, filepath, fileId));
        }
    }
    public void onDeleteButtonClick(View v) {
        String File = v.getTag().toString();
        FilePN = File.split("--");
        AlertDialog diaBox = delete();
        diaBox.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_about) {
            AlertDialog diaBox = about();
            diaBox.show();
        }

        return super.onOptionsItemSelected(item);
    }

    private AlertDialog about() {

        AlertDialog myQuittingDialogBox = new AlertDialog.Builder(this)

                .setTitle("About")
                .setMessage("The app is created by Pial and Pranti")
                .setNegativeButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();
        return myQuittingDialogBox;

    }

    private AlertDialog delete() {

        AlertDialog deleteMessage = new AlertDialog.Builder(this)

                .setTitle("Delete File")
                .setMessage("Are you sure you want to permanently delete " + FilePN[1] + "?")
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        deleteFile(FilePN[0], FilePN[1], FilePN[2]);
                    }
                })

                .create();
        return deleteMessage;

    }

    public void deleteFile(String FileID, String FileName, String FilePath) {
        if (!FilePath.matches("")) {
            FilePath = FilePath + "/";
        }
        String fpath = Environment.getExternalStoragePublicDirectory("").toString() + "/" + FilePath + FileName + ".txt";
        File file = new File(fpath);
        boolean deleted = file.delete();
        if (deleted) {
            Toast.makeText(getBaseContext(), FileName + " is deleted!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getBaseContext(), "Already your file is deleted!", Toast.LENGTH_LONG).show();
        }
        helper.deleteText(Integer.parseInt(FileID));
        getList();
    }



    public void onBackPressed() {
        AlertDialog diaBox = exit();
        diaBox.show();
    }

    private AlertDialog exit()
    {
        AlertDialog exitM =new AlertDialog.Builder(this)
                .setTitle("Exit")
                .setMessage("Do you want to exit NoteTakers?")

                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        finish();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .create();
        return exitM;

    }

    @Override
    protected void onStop() {
        super.onStop();
        finish();
    }
}

package com.pial.notepad;


public class FileName {
    String Filename ,Path;

    public void setFilename(String Fname)
    {
        this.Filename = Fname;
    }
    public String getFilename()
    {
        return this.Filename;
    }
    public void setPath(String path)
    {
        this.Path = path;
    }
    public String getPath()
    {
        return this.Path;
    }
}

<table border=0>
<tr>

<td>

[![Build Status](https://travis-ci.org/aminyazdanpanah/NotePad.svg?branch=master)](https://travis-ci.org/aminyazdanpanah/NotePad)
[![API](https://img.shields.io/badge/API-15%2B-brightgreen.svg?style=flat)](https://android-arsenal.com/api?level=15)
## 📝 Simple Notepad
Simple notepad that can use for learning android code.
## Usage
To write something in your Android smart phone
## Installation
1. Clone it `git clone https://github.com/aminyazdanpanah/NotePad.git`
2. Build it with Android Studio
3. Enjoy it :D
## History
V1.0
## License
© Copyright 2017 Amin Yazdanpanah


</td>
<td width=300px>
<img src="http://www.aminyazdanpanah.com/public/images/Notepad.gif" width="300px">
</td>
</tr>
</table>
